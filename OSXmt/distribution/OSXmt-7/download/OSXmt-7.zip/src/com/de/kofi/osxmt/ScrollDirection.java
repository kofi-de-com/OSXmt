package com.de.kofi.osxmt;

public enum ScrollDirection {
	UNDEFINED, VERTICAL, HORIZONTAL
}
